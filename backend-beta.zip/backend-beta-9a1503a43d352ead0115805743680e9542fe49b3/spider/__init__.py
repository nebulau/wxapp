# -*- coding: utf-8 -*-
LOG_PATH = "./spider/log/"
AIRP_DATA_PKLS = "./spider/airp_data_pkls/"
ORI_IMG_PATH = "./spider/img_file/"
COMBINED_IMG_PATH = "./spider/combined_imgs/"
AUTH_CODE_IMG_PATH = "./spider/auth_code_imgs/"

OCR_TYPE = 1
